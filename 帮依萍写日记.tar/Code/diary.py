for a in range(1,11):
	print('书桓走的第{}天，想他'.format(a))
